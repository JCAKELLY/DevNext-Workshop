﻿$ErrorActionPreference = 'SilentlyContinue'
$results =    jf rt s --spec=find-artifacts-match-naming-pattern-filespec.json | ConvertFrom-Json


Write-Host "------------------"
Write-host $results[0].path
Write-Host "------------------"